#Script written and analyzed in R 4.3.1 and RStudio 2024.12.1+563 in Microsoft Windows 10 Pro

#************************************************************
#Test of Significance of variables between IBs for FC & SC
#************************************************************
## Step 1: Set Working Directory
setwd("C:")
getwd()

# Load necessary libraries
library(dplyr)
library(tidyr)
library(flextable)
library(officer)

# Load the dataset
data <- read.csv("IO_data_RA.csv")

# Separate data for FC and SC seasons
data_FC <- data %>% filter(CS == "FC")
data_SC <- data %>% filter(CS == "SC")

# Identify numeric columns
numeric_columns <- data %>% select(where(is.numeric)) %>% colnames()

# --- SHAPIRO-WILK NORMALITY TEST ---
# Function to perform Shapiro-Wilk normality test
get_shapiro_pvalue <- function(values) {
  if (length(values) > 3) {  # Shapiro-Wilk requires at least 3 values
    return(tryCatch(shapiro.test(values)$p.value, error = function(e) NA))
  } else {
    return(NA)  # Not enough data for normality test
  }
}

# Perform normality test for each IB and variable
normality_results <- data %>%
  pivot_longer(all_of(numeric_columns), names_to = "Variable", values_to = "Value") %>%
  filter(!is.na(Value)) %>%
  group_by(IB, Variable) %>%
  summarise(
    P_Value = get_shapiro_pvalue(Value),
    Normality = case_when(
      is.na(P_Value) ~ "Insufficient Data",
      P_Value < 0.05 ~ "Non-Normal",
      TRUE ~ "Normal"
    ),
    .groups = "drop"
  ) %>%
  mutate(P_Value = round(P_Value, 3))  # Round p-values

# Reshape results for better readability
normality_table <- normality_results %>%
  pivot_wider(names_from = IB, values_from = c(P_Value, Normality), names_sep = "_") %>%
  arrange(Variable)

# Save Normality Test Results to Word
ft_norm <- flextable(normality_table) %>% autofit()
doc_norm <- read_docx() %>% body_add_flextable(ft_norm)
print(doc_norm, target = "Normality_Test_Results_IB.docx")

cat("Normality test results saved to 'Normality_Test_Results_IB.docx'\n")

# --- WILCOXON RANK-SUM TEST FOR IB GROUPS ---
# Define IB comparison pairs
comparison_pairs <- list(
  "IB1_vs_IB4" = c("IB1", "IB4"),
  "IB2_vs_IB4" = c("IB2", "IB4"),  # Fixed duplicate
  "IB3_vs_IB4" = c("IB3", "IB4")
)

# Function to perform Wilcoxon's rank-sum test
perform_wilcox_test <- function(data, var, group1, group2) {
  values1 <- data %>% filter(IB == group1) %>% pull(!!sym(var))
  values2 <- data %>% filter(IB == group2) %>% pull(!!sym(var))
  
  # Remove NAs correctly using `na.omit()`
  values1 <- na.omit(values1)
  values2 <- na.omit(values2)
  
  if (length(values1) >= 3 & length(values2) >= 3) {  # Ensure enough observations
    test_p_value <- tryCatch(
      wilcox.test(values1, values2, exact = FALSE)$p.value,
      error = function(e) NA
    )
    return(case_when(
      is.na(test_p_value) ~ "",
      test_p_value < 0.001 ~ "***",
      test_p_value < 0.01 ~ "**",
      test_p_value < 0.05 ~ "*",
      TRUE ~ ""
    ))
  } else {
    return("Insufficient Data")
  }
}

# Function to calculate Wilcoxon tests for all variables
wilcox_test_results <- function(data, numeric_columns) {
  results <- lapply(numeric_columns, function(var) {
    sapply(comparison_pairs, function(pair) {
      perform_wilcox_test(data, var, pair[1], pair[2])
    })
  }) %>%
    do.call(rbind, .) %>%
    as.data.frame()
  
  results <- cbind(Variable = numeric_columns, results)  # Add variable names
  colnames(results) <- c("Variable", "IB1 vs IB4", "IB2 vs IB4", "IB3 vs IB4")
  return(results)
}

# Perform Wilcoxon tests for FC and SC separately
results_FC <- wilcox_test_results(data_FC, numeric_columns)
results_SC <- wilcox_test_results(data_SC, numeric_columns)

# Save Wilcoxon test results to Word
ft_FC <- flextable(results_FC) %>% autofit()
doc_FC <- read_docx() %>% 
  body_add_par("Wilcoxon Test Results for FC Season", style = "heading 1") %>%
  body_add_flextable(ft_FC)
print(doc_FC, target = "Wilcoxon_Test_Results_FC.docx")

ft_SC <- flextable(results_SC) %>% autofit()
doc_SC <- read_docx() %>%
  body_add_par("Wilcoxon Test Results for SC Season", style = "heading 1") %>%
  body_add_flextable(ft_SC)
print(doc_SC, target = "Wilcoxon_Test_Results_SC.docx")

# Save Wilcoxon test results as CSV
write.csv(results_FC, "Wilcoxon_Test_Results_FC.csv", row.names = FALSE)
write.csv(results_SC, "Wilcoxon_Test_Results_SC.csv", row.names = FALSE)

cat("Wilcoxon test results saved for FC and SC in Word & CSV files.\n")
