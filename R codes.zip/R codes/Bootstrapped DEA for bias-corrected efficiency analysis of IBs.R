#Script written and analyzed in R 4.3.1 and RStudio 2024.12.1+563 in Microsoft Windows 10 Pro

##****************************************************************************
## Frontier efficiency analysis of Cambodian rice data using bootstrapped DEA
##****************************************************************************

#Step 1: Setting working directory and calling libraries
#*******************************************************
## Step 1.1: Set Working Directory
## Set path to folder containing 'IO_data_RA.csv' in your computer
setwd("YourDrive:/Your/Folder/Path") 
getwd()

## Step 2: Load Necessary Libraries
library(Benchmarking)
library(dplyr)
library(officer)
library(flextable)
library(ggplot2)
library(gridExtra)

## Step 3: Load Input-Output Data for Rice Production from Cambodian Farm Households
IO_dat <- read.csv("IO_data_RA.csv")

## Step 4: Check Data Structure
head(IO_dat)
names(IO_dat)

## Step 5: Subset Data for Rice Year 2019-2020 and by Crop Season (FC and SC)
# FC = First Crop, SC = Second Crop
IO_data1 <- subset(IO_dat, RY == "2019-2020")
IO_data1_FC <- subset(IO_data1, CS == "FC")
IO_data1_SC <- subset(IO_data1, CS == "SC")

## Step 6: Define Input and Output Variables for DEA Analysis
input_columns <- c("RA", "SR", "FERTC", "HERBC", "PESTC", "RODC", "LPC", "CEC", 
                   "IFC", "FALC", "PALC", "HALC", "HARVC")
output_column <- "GSI"

## Step 7: Function to Clean Numeric Columns and Handle Missing Values
clean_numeric <- function(x) {
  x <- as.numeric(as.character(x))  # Convert to numeric
  x[!is.finite(x)] <- NA  # Replace Inf, -Inf, NaN with NA
  return(x)
}

## Step 8: Convert Inputs & Outputs to Numeric and Handle Missing Values
IO_data1_FC <- IO_data1_FC %>%
  mutate(across(all_of(input_columns), clean_numeric)) %>%
  mutate(!!output_column := clean_numeric(.data[[output_column]]))

IO_data1_SC <- IO_data1_SC %>%
  mutate(across(all_of(input_columns), clean_numeric)) %>%
  mutate(!!output_column := clean_numeric(.data[[output_column]]))

## Step 9: Remove Rows with Missing Values Before Conversion to Matrices
IO_data1_FC <- IO_data1_FC %>% filter(complete.cases(across(all_of(c(input_columns, output_column)))))
IO_data1_SC <- IO_data1_SC %>% filter(complete.cases(across(all_of(c(input_columns, output_column)))))

## Step 10: Create Input and Output Matrices
input_matrix_FC <- as.matrix(IO_data1_FC[input_columns])
output_matrix_FC <- as.matrix(IO_data1_FC[[output_column]])
input_matrix_SC <- as.matrix(IO_data1_SC[input_columns])
output_matrix_SC <- as.matrix(IO_data1_SC[[output_column]])

## Step 11: Perform DEA with Bootstrapping (if valid rows exist)
n_boot <- 10000  # Number of bootstrap replications

if (nrow(input_matrix_FC) > 1 && all(complete.cases(input_matrix_FC, output_matrix_FC))) {
  boot_result_FC <- dea.boot(X = input_matrix_FC, Y = output_matrix_FC, 
                             NREP = n_boot, RTS = "vrs", ORIENTATION = "in")
  IO_data1_FC <- IO_data1_FC %>%
    mutate(efficiency_bias_corrected = boot_result_FC$eff.bc)
} else {
  stop("Error: Not enough valid data for DEA analysis in FC.")
}

if (nrow(input_matrix_SC) > 1 && all(complete.cases(input_matrix_SC, output_matrix_SC))) {
  boot_result_SC <- dea.boot(X = input_matrix_SC, Y = output_matrix_SC, 
                             NREP = n_boot, RTS = "vrs", ORIENTATION = "in")
  IO_data1_SC <- IO_data1_SC %>%
    mutate(efficiency_bias_corrected = boot_result_SC$eff.bc)
} else {
  stop("Error: Not enough valid data for DEA analysis in SC.")
}

## Step 12: Save Data with Efficiency Scores
write.csv(IO_data1_FC, "IO_data1_FC_bias_corrected.csv", row.names = FALSE)
write.csv(IO_data1_SC, "IO_data1_SC_bias_corrected.csv", row.names = FALSE)

message("DEA efficiency analysis completed successfully, & results saved.")

## Step 13: Visualization of Bias-Corrected Efficiency Scores

# Function to calculate mean efficiency scores for each group (e.g., mDSR use and IBs)
calculate_means <- function(data, group_var, efficiency_var, season) {
  data %>%
    filter(!is.na(.data[[group_var]])) %>%
    group_by(.data[[group_var]]) %>%
    summarise(mean_efficiency = mean(.data[[efficiency_var]], na.rm = TRUE), .groups = "drop") %>%
    mutate(Season = season,
           label = paste0("bar(italic(theta))['", .data[[group_var]], ", ", season, "'] == ", round(mean_efficiency, 2)))
}

# Adjust text position for better readability
text_y_position <- 4.0  

# === First Plot: Density of Efficiency Scores for USE (Adopters vs. Non-Adopters) ===
means_USE_FC <- calculate_means(IO_data1_FC, "USE", "efficiency_bias_corrected", "FC")
means_USE_SC <- calculate_means(IO_data1_SC, "USE", "efficiency_bias_corrected", "SC")
means_USE_combined <- bind_rows(means_USE_FC, means_USE_SC)

density_USE_combined <- ggplot(bind_rows(IO_data1_FC %>% mutate(Season = "FC"), 
                                         IO_data1_SC %>% mutate(Season = "SC")), 
                               aes(x = efficiency_bias_corrected, fill = as.factor(USE))) +
  geom_density(alpha = 0.5) +
  geom_vline(data = means_USE_combined, aes(xintercept = mean_efficiency, group = interaction(USE, Season)),
             linetype = "dotted", color = "black", linewidth = 1) +
  geom_text(data = means_USE_combined, aes(x = mean_efficiency, y = text_y_position, 
                                           label = label, group = interaction(USE, Season)),
            color = "black", angle = 90, vjust = -1, parse = TRUE) +  
  scale_fill_manual(values = c("No" = "blue", "Yes" = "green"), labels = c("Non-Adopters", "Adopters")) +
  facet_grid(rows = vars(Season)) +  
  theme_minimal() +
  labs(title = "Density of Efficiency Scores by Adoption Status (USE) - FC & SC",
       x = "Efficiency Scores",
       y = "Density") +
  theme(legend.position = "top", legend.title = element_blank())

# === Second Plot: Density of Efficiency Scores for IB Groups ===
means_IB_FC <- calculate_means(IO_data1_FC, "IB", "efficiency_bias_corrected", "FC")
means_IB_SC <- calculate_means(IO_data1_SC, "IB", "efficiency_bias_corrected", "SC")
means_IB_combined <- bind_rows(means_IB_FC, means_IB_SC)

density_IB_combined <- ggplot(bind_rows(IO_data1_FC %>% mutate(Season = "FC"), 
                                        IO_data1_SC %>% mutate(Season = "SC")), 
                              aes(x = efficiency_bias_corrected, fill = IB)) +
  geom_density(alpha = 0.5) +
  geom_vline(data = means_IB_combined, aes(xintercept = mean_efficiency, group = interaction(IB, Season)),
             linetype = "dotted", color = "black", linewidth = 1) +
  geom_text(data = means_IB_combined, aes(x = mean_efficiency, y = text_y_position, 
                                          label = label, group = interaction(IB, Season)),
            color = "black", angle = 90, vjust = -1, parse = TRUE) +
  facet_grid(rows = vars(Season)) +  
  theme_minimal() +
  labs(title = "Density of Efficiency Scores by IB - FC & SC",
       x = "Efficiency Scores",
       y = "Density") +
  theme(legend.position = "top", legend.title = element_blank())

# First plot: Adopters vs. Non-Adopters (mDSR USE)
density_USE_combined  

# Second plot: IB Groups
density_IB_combined  

