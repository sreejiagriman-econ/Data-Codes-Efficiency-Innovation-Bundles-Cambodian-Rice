#Script written and analyzed in R 4.3.1 and RStudio 2024.12.1+563 in Microsoft Windows 10 Pro

#Setting working directory and calling libraries
#*******************************************************
## Set Working Directory
## Set path to folder containing 'IO_data_RA.csv' in your computer
setwd("YourDrive:/Your/Folder/Path") 
getwd()

# Load necessary libraries
library(ggplot2)
library(dplyr)
library(patchwork)  # For combining plots


# Load the data
ML_data <- read.csv("ML_data.csv")

# Function to remove outliers using IQR
remove_outliers <- function(data, column) {
  Q1 <- quantile(data[[column]], 0.25, na.rm = TRUE)
  Q3 <- quantile(data[[column]], 0.75, na.rm = TRUE)
  IQR <- Q3 - Q1
  data %>% filter(data[[column]] >= (Q1 - 1.5 * IQR) & data[[column]] <= (Q3 + 1.5 * IQR))
}

# Remove outliers
cleaned_data <- ML_data %>%
  group_by(MOP) %>%
  filter(!is.na(YIELD), !is.na(efficiency_bias_corrected), !is.na(CS)) %>%
  do(remove_outliers(., "YIELD")) %>%
  do(remove_outliers(., "efficiency_bias_corrected"))

# Define mapping of MOP values to IB labels
MOP_mapping <- c("mDSR+CH" = "IB1", "mDSR+M" = "IB2", "NomDSR+CH" = "IB3", "NomDSR+M" = "IB4")

# Apply the mapping
cleaned_data <- cleaned_data %>%
  mutate(MOP_IB = recode(MOP, !!!MOP_mapping))

# Define IB colors
MOP_colors <- c("IB1" = "limegreen", "IB2" = "steelblue1", "IB3" = "hotpink", "IB4" = "orangered3")

# Compute mean values for annotation
mean_values <- cleaned_data %>%
  group_by(CS, MOP_IB) %>%
  summarise(
    avg_YIELD = mean(YIELD, na.rm = TRUE),
    avg_efficiency = mean(efficiency_bias_corrected, na.rm = TRUE),
    .groups = "drop"
  )

# Separate data for FC and SC
data_FC <- cleaned_data %>% filter(CS == "FC")
data_SC <- cleaned_data %>% filter(CS == "SC")
mean_FC <- mean_values %>% filter(CS == "FC")
mean_SC <- mean_values %>% filter(CS == "SC")

# Define common axis limits and breaks for uniform comparison
x_limits <- c(2.5, 6.5)  # Yield axis range
y_limits <- c(0.2, 1.0)   # Efficiency axis range
x_breaks <- seq(2.5, 6.5, by = 0.5)
y_breaks <- seq(0.2, 1.0, by = 0.2)

# Function to create individual plots with uniform axes and border
create_plot <- function(data, mean_values, title) {
  ggplot(data, aes(x = YIELD, y = efficiency_bias_corrected, color = MOP_IB, fill = MOP_IB)) +
    geom_point(alpha = 0.6, size = 2) +  
    stat_ellipse(geom = "polygon", alpha = 0.2, level = 0.8) +  # Cluster circles
    geom_text(data = mean_values, aes(x = avg_YIELD, y = avg_efficiency,
                                      label = paste0("(", round(avg_YIELD, 2), ", ", round(avg_efficiency, 2), ")")),
              color = "black", size = 3, vjust = -0.5) +  
    scale_color_manual(values = MOP_colors) +  
    scale_fill_manual(values = MOP_colors) +  
    scale_x_continuous(limits = x_limits, breaks = x_breaks) +  # Uniform X-axis
    scale_y_continuous(limits = y_limits, breaks = y_breaks) +  # Uniform Y-axis
    labs(
      title = title,
      x = "Rice Yield (t ha⁻¹)",
      y = "Bias-Corrected Efficiency",
      color = "Innovation Bundles",
      fill = "Innovation Bundles"
    ) +
    theme_minimal() +
    theme(
      legend.position = "bottom",
      plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
      axis.text = element_text(size = 10),
      axis.title = element_text(size = 12, face = "bold"),
      
      # Border for each panel
      panel.border = element_rect(color = "black", linewidth = 1.5, fill = NA)
    )
}

# Create plots with uniform axes and borders
plot_FC <- create_plot(data_FC, mean_FC, "A. Dry season rice (2019-2020)")
plot_SC <- create_plot(data_SC, mean_SC, "B. Wet season rice (2019-2020)")

# Combine the two plots with patchwork and shared legend
combined_plot <- plot_FC + plot_SC + 
  plot_layout(ncol = 2, guides = "collect") +  # Shared legend
  plot_annotation(title = "Efficiency vs Yield for Dry & Wet Season")  # Adds title without affecting layout

# Print the combined plot
print(combined_plot)


# Generate summary statistics for YIELD and Efficiency
summary_stats <- cleaned_data %>%
  group_by(CS, IB) %>%
  summarise(
    avg_YIELD = mean(YIELD, na.rm = TRUE),
    sd_YIELD = sd(YIELD, na.rm = TRUE),
    min_YIELD = min(YIELD, na.rm = TRUE),
    max_YIELD = max(YIELD, na.rm = TRUE),
    avg_efficiency = mean(efficiency_bias_corrected, na.rm = TRUE),
    sd_efficiency = sd(efficiency_bias_corrected, na.rm = TRUE),
    min_efficiency = min(efficiency_bias_corrected, na.rm = TRUE),
    max_efficiency = max(efficiency_bias_corrected, na.rm = TRUE),
    count = n()
  ) %>%
  arrange(CS, IB)

# Print the summary statistics to console
print(summary_stats)

# Save summary statistics as CSV
write.csv(summary_stats, "Efficiency_vs_Yield_Summary_Stats.csv", row.names = FALSE)

message("Summary statistics saved as 'Efficiency_vs_Yield_Summary_Stats.csv'.")


